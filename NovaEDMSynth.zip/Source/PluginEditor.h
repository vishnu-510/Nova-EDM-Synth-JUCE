#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "SoundOrbitComponent.h"
#include "MetalLookAndFeel.h"

class NovaEDMSynthAudioProcessorEditor  : public juce::AudioProcessorEditor,
                                         private juce::Timer
{
public:
    NovaEDMSynthAudioProcessorEditor (NovaEDMSynthAudioProcessor&);
    ~NovaEDMSynthAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void drawWiderMeter (juce::Graphics& g);

    NovaEDMSynthAudioProcessor& processor;

    SoundOrbitComponent orbit;
    juce::MidiKeyboardComponent keyboard;

    juce::Slider genreKnob, presetKnob;
    juce::Slider reverbKnob, delayKnob, chorusKnob, filterKnob, attackKnob, widerSlider;

    juce::Label genreLabel, presetLabel;
    juce::Label reverbLabel, delayLabel, chorusLabel, filterLabel, attackLabel, widerLabel;
    juce::Label displayGenre, displayPreset;

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> genreAttach, presetAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> reverbAttach, delayAttach, chorusAttach, filterAttach, attackAttach, widerAttach;

    MetalLookAndFeel metalLF;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NovaEDMSynthAudioProcessorEditor)
};
