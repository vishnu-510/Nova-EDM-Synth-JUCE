#include "MetalLookAndFeel.h"

MetalLookAndFeel::MetalLookAndFeel() {}

void MetalLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                                         float sliderPos, float rotaryStartAngle,
                                         float rotaryEndAngle, juce::Slider&)
{
    auto bounds = juce::Rectangle<float>(x, y, width, height).reduced(4.0f);
    auto radius = bounds.getWidth() * 0.5f;
    auto centre = bounds.getCentre();

    juce::Colour metalDark  = juce::Colour::fromRGB (2, 4, 18);
    juce::Colour metalLight = juce::Colour::fromRGB (10, 18, 60);
    juce::Colour orbitBlue  = juce::Colour::fromRGB (40, 120, 255);

    // Dark metallic gradient
    g.setGradientFill (juce::ColourGradient (
        metalLight, centre.x, centre.y - radius,
        metalDark,  centre.x, centre.y + radius,
        true));
    g.fillEllipse (bounds);

    g.setColour (juce::Colour::fromRGB (140, 140, 150));
    g.drawEllipse (bounds, 1.2f);
    
    const float startAngle = juce::MathConstants<float>::pi * 0.75f; // 135° = left-bottom on screen
    const float endAngle   = startAngle + juce::MathConstants<float>::twoPi * 0.75f; // 270° sweep clockwise

    float angle = startAngle + sliderPos * (endAngle - startAngle);

    auto dotPos = centre + juce::Point<float>(
        std::cos(angle),
        std::sin(angle)
    ) * (radius * 0.78f);

    g.setColour (orbitBlue);
    g.fillEllipse (dotPos.x - 3.5f, dotPos.y - 3.5f, 7.0f, 7.0f);
}

void MetalLookAndFeel::drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                                         float sliderPos, float, float,
                                         const juce::Slider::SliderStyle, juce::Slider&)
{
    auto track = juce::Rectangle<float> (x, y + height * 0.45f, width, 4.0f);

    juce::Colour baseBlue      = juce::Colour::fromRGB (8, 14, 32);
    juce::Colour highlightBlue = juce::Colour::fromRGB (30, 60, 120);
    juce::Colour orbitBlue     = juce::Colour::fromRGB (40, 120, 255);

    juce::ColourGradient grad (highlightBlue, track.getX(), track.getY(),
                               baseBlue, track.getRight(), track.getY(), false);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (track, 2.0f);

    g.setColour (orbitBlue);
    g.fillEllipse (sliderPos - 4.0f, track.getCentreY() - 4.0f, 8.0f, 8.0f);
}

void MetalLookAndFeel::drawLabel (juce::Graphics& g, juce::Label& label)
{
    auto r = label.getLocalBounds().toFloat();

    juce::Colour baseBlue = juce::Colour::fromRGB (8, 14, 32);

    // Optional: very subtle dark fill behind text (or remove this too if you want totally flat)


    // NO BORDER ANYMORE

    g.setColour (juce::Colours::white);
    g.setFont (14.0f);
    g.drawFittedText (label.getText(),
                      label.getLocalBounds(),
                      juce::Justification::centred,
                      1);
}
