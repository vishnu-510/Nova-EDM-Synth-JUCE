#include "PluginEditor.h"

NovaEDMSynthAudioProcessorEditor::NovaEDMSynthAudioProcessorEditor (NovaEDMSynthAudioProcessor& p)
    : AudioProcessorEditor (&p),
      processor (p),
      keyboard (p.keyboardState, juce::MidiKeyboardComponent::horizontalKeyboard)
{
    setSize (1000, 480);
    setLookAndFeel (&metalLF);

    auto setupKnob = [&](juce::Slider& s)
    {
        s.setSliderStyle (juce::Slider::RotaryVerticalDrag);
        s.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        s.setLookAndFeel (&metalLF);
        addAndMakeVisible (s);
    };

    auto setupSlider = [&](juce::Slider& s)
    {
        s.setSliderStyle (juce::Slider::LinearHorizontal);
        s.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        s.setLookAndFeel (&metalLF);
        addAndMakeVisible (s);
    };

    setupKnob (genreKnob);
    setupKnob (presetKnob);
    setupKnob (reverbKnob);
    setupKnob (delayKnob);
    setupKnob (chorusKnob);
    setupKnob (filterKnob);
    setupKnob (attackKnob);
    setupSlider (widerSlider);

    widerSlider.setRange (-1.0, 1.0, 0.001);

    addAndMakeVisible (orbit);

    keyboard.setKeyWidth (20.0f);
    keyboard.setColour (juce::MidiKeyboardComponent::keyDownOverlayColourId,
                        juce::Colour::fromRGB (40,120,255).withAlpha (0.6f));
    addAndMakeVisible (keyboard);

    auto setupLabel = [&](juce::Label& l, const juce::String& text)
    {
        l.setText (text, juce::dontSendNotification);
        l.setJustificationType (juce::Justification::centredLeft);
        l.setColour (juce::Label::textColourId, juce::Colours::white);
        l.setLookAndFeel (&metalLF);
        addAndMakeVisible (l);
    };

    setupLabel (genreLabel, "GENRE");
    setupLabel (presetLabel, "PRESET");
    setupLabel (reverbLabel, "REVERB");
    setupLabel (delayLabel, "DELAY");
    setupLabel (chorusLabel, "CHORUS");
    setupLabel (filterLabel, "FILTER");
    setupLabel (attackLabel, "ATTACK");
    setupLabel (widerLabel, "WIDER");

    displayGenre.setColour (juce::Label::textColourId, juce::Colours::white);
    displayPreset.setColour (juce::Label::textColourId, juce::Colours::white);
    displayGenre.setJustificationType (juce::Justification::centredLeft);
    displayPreset.setJustificationType (juce::Justification::centredLeft);
    addAndMakeVisible (displayGenre);
    addAndMakeVisible (displayPreset);

    genreAttach  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.parameters, "GENRE", genreKnob);
    presetAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.parameters, "PRESET", presetKnob);
    reverbAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.parameters, "REVERB", reverbKnob);
    delayAttach  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.parameters, "DELAY", delayKnob);
    chorusAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.parameters, "CHORUS", chorusKnob);
    filterAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.parameters, "FILTER", filterKnob);
    attackAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.parameters, "ATTACK", attackKnob);
    widerAttach  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.parameters, "WIDER", widerSlider);

    startTimerHz (30);
}

NovaEDMSynthAudioProcessorEditor::~NovaEDMSynthAudioProcessorEditor()
{
    setLookAndFeel (nullptr);
}

void NovaEDMSynthAudioProcessorEditor::timerCallback()
{
    // === DISPLAY TEXT ===
    displayGenre.setText ("GENRE: " + processor.getCurrentGenreName(), juce::dontSendNotification);
    displayPreset.setText ("PRESET: " + processor.getCurrentPresetName(), juce::dontSendNotification);

    // === ORBIT PARAMETER SWAP (CHORUS <-> ATTACK) ===
    orbit.setWidthAmount (widerSlider.getValue());
    orbit.setAttackAmount (chorusKnob.getValue());   // swapped
    orbit.setFilterAmount (filterKnob.getValue());
    orbit.setReverbAmount (reverbKnob.getValue());
    orbit.setDelayAmount  (delayKnob.getValue());
    orbit.setChorusAmount (attackKnob.getValue());   // swapped

    repaint();
}

void NovaEDMSynthAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::black);

    juce::Random rng (42);
    float t = (float) juce::Time::getMillisecondCounterHiRes() * 0.00008f;

    for (int i = 0; i < 180; ++i)
    {
        float x = std::fmod (rng.nextFloat() * getWidth()  + t * 60.0f, (float)getWidth());
        float y = std::fmod (rng.nextFloat() * getHeight() + t * 30.0f, (float)getHeight());

        float size = 1.2f + rng.nextFloat() * 2.0f;
        g.setColour (juce::Colours::white.withAlpha (0.12f));
        g.fillEllipse (x, y, size, size);
    }

    drawWiderMeter (g);
}

void NovaEDMSynthAudioProcessorEditor::resized()
{
    orbit.setBounds (40, 40, 260, 160);

    genreKnob.setBounds  (320, 55, 120, 120);
    presetKnob.setBounds (500, 55, 120, 120);

    genreLabel.setBounds  (320, 175, 120, 20);
    presetLabel.setBounds (500, 175, 120, 20);

    displayGenre.setBounds  (700, 60, 260, 28);
    displayPreset.setBounds (700, 95, 260, 28);

    widerSlider.setBounds (60, 280, 160, 22);
    widerLabel.setBounds  (60, 305, 160, 20);

    const int knobSize = 82;

    reverbKnob.setBounds (320, 255, knobSize, knobSize);
    delayKnob.setBounds  (420, 255, knobSize, knobSize);
    chorusKnob.setBounds (520, 255, knobSize, knobSize);
    filterKnob.setBounds (620, 255, knobSize, knobSize);
    attackKnob.setBounds (720, 255, knobSize, knobSize);

    reverbLabel.setBounds (320, 340, knobSize, 20);
    delayLabel.setBounds  (420, 340, knobSize, 20);
    chorusLabel.setBounds (520, 340, knobSize, 20);
    filterLabel.setBounds (620, 340, knobSize, 20);
    attackLabel.setBounds (720, 340, knobSize, 20);

    keyboard.setBounds (20, 380, getWidth() - 40, 70);
}

void NovaEDMSynthAudioProcessorEditor::drawWiderMeter (juce::Graphics& g)
{
    auto area = widerSlider.getBounds().toFloat();
    float value = widerSlider.getValue();

    float width = std::abs(value) * area.getWidth();
    float y = area.getCentreY() - 2.0f;

    juce::Rectangle<float> bar = value >= 0.0f ?
        juce::Rectangle<float> (area.getX(), y, width, 4.0f) :
        juce::Rectangle<float> (area.getRight() - width, y, width, 4.0f);

    g.setColour (juce::Colour::fromRGB (40,120,255));
    g.fillRoundedRectangle (bar, 2.0f);
}
