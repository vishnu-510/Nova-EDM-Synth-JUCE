#pragma once
#include <JuceHeader.h>

class MetalLookAndFeel : public juce::LookAndFeel_V4
{
public:
    MetalLookAndFeel();

    void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                           float sliderPosProportional, float rotaryStartAngle,
                           float rotaryEndAngle, juce::Slider& slider) override;

    void drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                           float sliderPos, float minSliderPos, float maxSliderPos,
                           const juce::Slider::SliderStyle style, juce::Slider& slider) override;

    void drawLabel (juce::Graphics& g, juce::Label& label) override;

private:
    juce::Colour metalDark  = juce::Colour::fromRGB (8, 12, 28);     // very dark blue
    juce::Colour metalMid   = juce::Colour::fromRGB (20, 35, 80);
    juce::Colour baseBlue = juce::Colour::fromRGB (8, 18, 40);   // almost black blue
    juce::Colour highlightBlue = juce::Colour::fromRGB (30, 60, 120); // subtle edge shine
};
