#include "PluginProcessor.h"
#include "PluginEditor.h"

NovaEDMSynthAudioProcessor::NovaEDMSynthAudioProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      parameters (*this, nullptr, "PARAMS",
      {
          std::make_unique<juce::AudioParameterFloat>("REVERB","Reverb",0,1,0),
          std::make_unique<juce::AudioParameterFloat>("DELAY","Delay",0,1,0),
          std::make_unique<juce::AudioParameterFloat>("CHORUS","Chorus",0,1,0),
          std::make_unique<juce::AudioParameterFloat>("FILTER","Filter",0,1,0.5f),
          std::make_unique<juce::AudioParameterFloat>("ATTACK","Attack",0.001f,2.0f,0.01f),
          std::make_unique<juce::AudioParameterFloat>("WIDER","Wider",-1.0f,1.0f,0.0f),
          std::make_unique<juce::AudioParameterInt>("GENRE","Genre",0,3,0),
          std::make_unique<juce::AudioParameterInt>("PRESET","Preset",0,15,0)
      })
{
    formatManager.registerBasicFormats();
    for (int i = 0; i < 16; ++i)
        sampler.addVoice (new juce::SamplerVoice());
}

NovaEDMSynthAudioProcessor::~NovaEDMSynthAudioProcessor() {}

bool NovaEDMSynthAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void NovaEDMSynthAudioProcessor::prepareToPlay (double sr, int bs)
{
    sampler.setCurrentPlaybackSampleRate (sr);

    dspSpec.sampleRate = sr;
    dspSpec.maximumBlockSize = bs;
    dspSpec.numChannels = 2;

    reverb.prepare (dspSpec);
    chorus.prepare (dspSpec);
    delay.prepare (dspSpec);
    filter.prepare (dspSpec);
    filter.setType (juce::dsp::StateVariableTPTFilterType::lowpass);
}

void NovaEDMSynthAudioProcessor::releaseResources() {}

void NovaEDMSynthAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    buffer.clear();
    keyboardState.processNextMidiBuffer (midi, 0, buffer.getNumSamples(), true);

    int genre  = *parameters.getRawParameterValue("GENRE");
    int preset = *parameters.getRawParameterValue("PRESET");

    if (genre != lastGenre || preset != lastPreset)
    {
        loadSampleFromFolder (genre, preset);
        lastGenre = genre;
        lastPreset = preset;
    }

    // === ATTACK ENVELOPE ===
    float attack = *parameters.getRawParameterValue("ATTACK");

    juce::ADSR::Parameters env;
    env.attack  = attack;
    env.decay   = 0.1f;
    env.sustain = 1.0f;
    env.release = 0.2f;

    for (int i = 0; i < sampler.getNumSounds(); ++i)
        if (auto* s = dynamic_cast<juce::SamplerSound*>(sampler.getSound(i).get()))
            s->setEnvelopeParameters (env);

    sampler.renderNextBlock (buffer, midi, 0, buffer.getNumSamples());

    juce::dsp::AudioBlock<float> block (buffer);
    juce::dsp::ProcessContextReplacing<float> ctx (block);

    float reverbAmt = *parameters.getRawParameterValue("REVERB");
    float delayAmt  = *parameters.getRawParameterValue("DELAY");
    float chorusAmt = *parameters.getRawParameterValue("CHORUS");
    float filterAmt = *parameters.getRawParameterValue("FILTER");
    float width     = 1.0f + *parameters.getRawParameterValue("WIDER");

    reverbParams.wetLevel = reverbAmt;
    reverb.setParameters (reverbParams);

    delay.setDelay (delayAmt * 500.0f);
    chorus.setDepth (chorusAmt);
    filter.setCutoffFrequency (200.0f + filterAmt * 8000.0f);

    filter.process (ctx);
    chorus.process (ctx);
    delay.process (ctx);
    reverb.process (ctx);

    auto* L = buffer.getWritePointer(0);
    auto* R = buffer.getWritePointer(1);

    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        float mid  = 0.5f * (L[i] + R[i]);
        float side = 0.5f * (L[i] - R[i]) * width;

        L[i] = mid + side;
        R[i] = mid - side;
    }
}

void NovaEDMSynthAudioProcessor::loadSampleFromFolder (int g, int p)
{
    sampler.clearSounds();

    juce::File root = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory)
                        .getChildFile ("NovaEDMSynth/Audio");

    juce::Array<juce::File> genres;
    root.findChildFiles (genres, juce::File::findDirectories, false);
    if (g >= genres.size()) return;

    currentGenreName = genres[g].getFileName();

    juce::Array<juce::File> wavs;
    genres[g].findChildFiles (wavs, juce::File::findFiles, true, "*.wav");
    if (p >= wavs.size()) return;

    currentPresetName = wavs[p].getFileNameWithoutExtension();

    if (auto* reader = formatManager.createReaderFor (wavs[p]))
    {
        juce::BigInteger notes;
        notes.setRange (0, 128, true);
        sampler.addSound (new juce::SamplerSound (currentPresetName, *reader, notes, 60, 0.01, 0.1, 10.0));
    }
}

// ===== REQUIRED VIRTUALS =====
int NovaEDMSynthAudioProcessor::getNumPrograms() { return 1; }
int NovaEDMSynthAudioProcessor::getCurrentProgram() { return 0; }
void NovaEDMSynthAudioProcessor::setCurrentProgram (int) {}
const juce::String NovaEDMSynthAudioProcessor::getProgramName (int) { return {}; }
void NovaEDMSynthAudioProcessor::changeProgramName (int, const juce::String&) {}
void NovaEDMSynthAudioProcessor::getStateInformation (juce::MemoryBlock&) {}
void NovaEDMSynthAudioProcessor::setStateInformation (const void*, int) {}

juce::AudioProcessorEditor* NovaEDMSynthAudioProcessor::createEditor()
{
    return new NovaEDMSynthAudioProcessorEditor (*this);
}

bool NovaEDMSynthAudioProcessor::hasEditor() const { return true; }
const juce::String NovaEDMSynthAudioProcessor::getName() const { return JucePlugin_Name; }
bool NovaEDMSynthAudioProcessor::acceptsMidi() const { return true; }
bool NovaEDMSynthAudioProcessor::producesMidi() const { return false; }
bool NovaEDMSynthAudioProcessor::isMidiEffect() const { return false; }
double NovaEDMSynthAudioProcessor::getTailLengthSeconds() const { return 0.0; }

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new NovaEDMSynthAudioProcessor();
}
