#include "SoundOrbitComponent.h"

SoundOrbitComponent::SoundOrbitComponent()
{
    startTimerHz (60);
}

void SoundOrbitComponent::setWidthAmount  (float w) { widthAmount  = juce::jlimit (-1.0f, 1.0f, w); }
void SoundOrbitComponent::setAttackAmount (float a) { attackAmount = juce::jlimit (0.0f, 1.0f, a); }
void SoundOrbitComponent::setFilterAmount (float f) { filterAmount = juce::jlimit (0.0f, 1.0f, f); }
void SoundOrbitComponent::setReverbAmount (float r) { reverbAmount = juce::jlimit (0.0f, 1.0f, r); }
void SoundOrbitComponent::setDelayAmount  (float d) { delayAmount  = juce::jlimit (0.0f, 1.0f, d); }
void SoundOrbitComponent::setChorusAmount (float c) { chorusAmount = juce::jlimit (0.0f, 1.0f, c); }

void SoundOrbitComponent::timerCallback()
{
    float speed = juce::jmap (attackAmount, 0.0f, 1.0f, 0.003f, 0.02f);
    angle += speed;
    pulsePhase += speed * 0.8f;
    repaint();
}

void SoundOrbitComponent::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::transparentBlack);

    auto area   = getLocalBounds().toFloat();
    auto center = area.getCentre();

    const float dotSize = 7.0f;
    float baseRadius = area.getHeight() * 0.28f;

    float maxRadiusX = (area.getWidth() * 0.5f) - dotSize;
    float maxStretch = maxRadiusX / baseRadius;
    float xStretch = 1.0f + std::abs(widthAmount) * (maxStretch - 1.0f);

    float pulse = 0.5f + 0.5f * std::sin (pulsePhase);
    float pulseScale = 1.0f + pulse * (attackAmount * 0.5f);

    // Orbit colour
    juce::Colour lightBlue = juce::Colour::fromRGB (120, 200, 255);
    juce::Colour deepBlue  = juce::Colour::fromRGB (30, 90, 255);
    juce::Colour orbitColour = lightBlue.interpolatedWith (deepBlue, filterAmount);

    // ===== REVERB PARTICLES =====
    int particleCount = 10 + (int)(reverbAmount * 60.0f);
    juce::Random rng (77);

    for (int i = 0; i < particleCount; ++i)
    {
        float a = rng.nextFloat() * juce::MathConstants<float>::twoPi + angle * 0.2f;
        float r = baseRadius * (1.1f + rng.nextFloat() * 0.8f) * pulseScale;

        float x = std::cos (a) * r;
        float y = std::sin (a) * r;

        float size  = 1.2f + rng.nextFloat() * 2.0f;
        float alpha = 0.12f + rng.nextFloat() * 0.35f;

        g.setColour (juce::Colours::white.withAlpha (alpha * (0.4f + reverbAmount)));
        g.fillEllipse (center.x + x - size * 0.5f,
                       center.y + y - size * 0.5f,
                       size, size);
    }

    // ===== ORBIT DOTS =====
    int trailCount = 2 + (int)(delayAmount * 4.0f);
    float trailSpacing = 0.25f + delayAmount * 0.35f;

    float chorusOffset = chorusAmount * 0.6f;
    float chorusScale  = 1.0f - chorusAmount * 0.15f;
    float chorusAlpha  = 0.6f * chorusAmount;

    for (int i = 0; i < 6; ++i)
    {
        float a = angle + juce::MathConstants<float>::twoPi * i / 6.0f;

        float x = std::cos(a) * baseRadius * xStretch * pulseScale;
        float y = std::sin(a) * baseRadius * pulseScale;

        // Glow halo
        g.setColour (orbitColour.withAlpha (0.2f));
        g.fillEllipse (center.x + x - dotSize,
                       center.y + y - dotSize,
                       dotSize * 2.0f,
                       dotSize * 2.0f);

        // Main dot
        g.setColour (orbitColour.withAlpha (0.95f));
        g.fillEllipse (center.x + x - dotSize * 0.5f,
                       center.y + y - dotSize * 0.5f,
                       dotSize, dotSize);

        // Delay trails
        for (int t = 1; t <= trailCount; ++t)
        {
            float ta = a - t * trailSpacing;
            float tx = std::cos(ta) * baseRadius * xStretch * pulseScale;
            float ty = std::sin(ta) * baseRadius * pulseScale;

            float alpha = juce::jmap ((float)t, 1.0f, (float)trailCount + 1.0f,
                                      0.4f, 0.1f) * delayAmount;

            g.setColour (juce::Colours::lightgrey.withAlpha (alpha));
            g.fillEllipse (center.x + tx - dotSize * 0.25f,
                           center.y + ty - dotSize * 0.25f,
                           dotSize * 0.7f, dotSize * 0.6f);
        }

        // Chorus layer
        if (chorusAmount > 0.01f)
        {
            float ca = a * 0.9f + chorusOffset;
            float cx = std::cos(ca) * baseRadius * xStretch * pulseScale * chorusScale;
            float cy = std::sin(ca) * baseRadius * pulseScale * chorusScale;

            g.setColour (orbitColour.withAlpha (chorusAlpha));
            g.fillEllipse (center.x + cx - dotSize * 0.25f,
                           center.y + cy - dotSize * 0.25f,
                           dotSize * 0.9f, dotSize * 0.6f);
        }
    }

    // ===== SUN CORE =====
    float sunRadius = 10.0f + pulse * 6.0f;

    juce::Colour sunInner = juce::Colour::fromRGB (255, 230, 150);
    juce::Colour sunOuter = juce::Colour::fromRGB (255, 120, 30);

    juce::ColourGradient sunGlow (sunInner, center.x, center.y,
                                  sunOuter, center.x, center.y + sunRadius * 2.0f,
                                  true);

    g.setGradientFill (sunGlow);
    g.fillEllipse (center.x - sunRadius * 1.6f,
                   center.y - sunRadius * 1.6f,
                   sunRadius * 3.2f,
                   sunRadius * 3.2f);

    g.setColour (juce::Colours::white.withAlpha (0.9f));
    g.fillEllipse (center.x - 4.0f, center.y - 4.0f, 8.0f, 8.0f);
}

void SoundOrbitComponent::resized() {}
