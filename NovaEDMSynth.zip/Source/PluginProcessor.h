#pragma once
#include <JuceHeader.h>

class NovaEDMSynthAudioProcessor  : public juce::AudioProcessor
{
public:
    NovaEDMSynthAudioProcessor();
    ~NovaEDMSynthAudioProcessor() override;

    void prepareToPlay (double, int) override;
    void releaseResources() override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    const juce::String getName() const override;
    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int) override;
    const juce::String getProgramName (int) override;
    void changeProgramName (int, const juce::String&) override;

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    bool isBusesLayoutSupported (const BusesLayout&) const override;

    juce::AudioProcessorValueTreeState parameters;

    juce::String getCurrentGenreName() const { return currentGenreName; }
    juce::String getCurrentPresetName() const { return currentPresetName; }

    juce::MidiKeyboardState keyboardState;

private:
    juce::Synthesiser sampler;
    juce::AudioFormatManager formatManager;

    juce::ADSR adsr;
    juce::ADSR::Parameters adsrParams;

    juce::dsp::ProcessSpec dspSpec;
    juce::dsp::Reverb reverb;
    juce::dsp::Reverb::Parameters reverbParams;
    juce::dsp::Chorus<float> chorus;
    juce::dsp::DelayLine<float> delay { 48000 };
    juce::dsp::StateVariableTPTFilter<float> filter;

    int lastGenre = -1, lastPreset = -1;
    juce::String currentGenreName, currentPresetName;

    void loadSampleFromFolder (int, int);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NovaEDMSynthAudioProcessor)
};
