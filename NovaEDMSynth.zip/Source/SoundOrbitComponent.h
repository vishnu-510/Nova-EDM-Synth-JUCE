#pragma once
#include <JuceHeader.h>

class SoundOrbitComponent : public juce::Component,
                            private juce::Timer
{
public:
    SoundOrbitComponent();

    void paint (juce::Graphics&) override;
    void resized() override;

    void setWidthAmount  (float w);
    void setAttackAmount (float a);
    void setFilterAmount (float f);
    void setReverbAmount (float r);
    void setDelayAmount  (float d);
    void setChorusAmount (float c);

private:
    void timerCallback() override;

    float angle = 0.0f;
    float widthAmount  = 0.0f;
    float attackAmount = 0.0f;
    float filterAmount = 0.0f;
    float reverbAmount = 0.0f;
    float delayAmount  = 0.0f;
    float chorusAmount = 0.0f;
    float pulsePhase   = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SoundOrbitComponent)
};
